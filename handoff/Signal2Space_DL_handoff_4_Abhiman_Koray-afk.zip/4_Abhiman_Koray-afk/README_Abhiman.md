# Signal2Space DL handoff: Abhiman (`Koray-afk`)

**Role:** Floor head & class imbalance (DL_03)
**Repository:** https://github.com/krishiv274/Signal2Space
**Planner:** https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
**Team plan:** `docs/TEAM_PLAN.md`
**Technical reference:** `docs/DL_PIPELINE.md` (also in `reference_files/`)

## 1. Project context (what already exists)

Signal2Space predicts building, floor and 2D position from Wi-Fi fingerprints (UJIIndoorLoc: 520 access points, where `100` means not detected).

**Phase 1 (AML).** Five Random Forest notebooks. Held-out results: building 99.73%, floor 88.93%, mean coordinate error 11.58 dataset units.

**Phase 2 (DL).** Already implemented and run end to end on branch `claude/peaceful-shannon-o1t6j8`:
- a PyTorch shared-trunk network with building, floor and coordinate heads;
- three single-task ablations;
- the AML-identical split, train-only preprocessing, early stopping and SHA-checked frozen evaluation.

**Held-out DL results.**
- Multitask: building 99.91%, floor 89.56%, mean error 12.00.
- Best single-task: building 99.82%, floor 89.92%, mean error 10.51.

Your job is to **verify, analyse and extend** your part, not to re-implement it.

## 2. Your assignment

### [DL-3] Floor head: per-building errors and class-weighting ablation (DL_03)
- **ID:** DL-3
- **Step:** 2 (Parallel member work (start now on pre-created branches; PRs after DL-0 merges; DL-1 merges first))
- **Branch:** `dl/03-floor-imbalance-Koray-afk`
- **Effort (estimate):** about 5–7 hours
- **Depends on:** DL-0
- **When to start:** Start now on your pre-created branch, in parallel with DL-1, DL-2 and DL-4; open the PR after DL-0 merges; merge after DL-1

**Goal.** Floor is the weakest classification task (held-out 89.9%; floor 4 recall 74%). Quantify where the errors happen and test class weighting with a decision rule fixed in advance.

**Scope**
- Run `DL_03_floor_prediction.ipynb` with `RETRAIN = False`.
- Break floor errors down by building and by true floor, for internal validation and held-out (descriptive). Save `data/tables/dl_03_floor_errors_by_building.csv`.
- Add the experiment `floor_only_weighted` to `config.EXPERIMENTS` and `EXPERIMENT_PREFIX` (prefix `dl_03_floor_weighted`), with `class_weighting=True` applied for that experiment only in `cli.run_train`. Train it with `python scripts/run_dl_pipeline.py train --experiments floor_only_weighted`.
- **Decision rule, fixed before you look at held-out results:** adopt weighting only if internal-validation macro F1 improves by at least 0.5 percentage points over `floor_only`. Then score held-out **once**, report it whatever the result, and record the decision in DL_03.

**Inputs**
- `models/dl_03_floor_model.pt`
- `src/signal2space_dl/config.py`, `cli.py`, `train.py`
- DL_03 notebook

**Outputs**
- New checkpoint `models/dl_03_floor_weighted_model.pt|json`
- Weighted-model metrics, per-class table and confusion matrix
- Error breakdown CSV and Findings in DL_03

**Acceptance criteria**
- [ ] The existing four checkpoints are unchanged. The new experiment is additive.
- [ ] The decision is made from internal-validation numbers only and written down before the held-out row.
- [ ] `pytest` passes, and `evaluate --experiments floor_only floor_only_weighted` runs.


## 3. Order of work and dependencies

1. Now: set up the environment (below), switch to your pre-created branch, run `evaluate`, and work through the scope items in order. You do not need to wait for anyone.
2. When PR #7 (DL-0) is merged: rebase on `main` and open your PR. Before that, open it as a draft.
3. Merge order: DL-1 (Gargi) first, then DL-2, DL-3 and DL-4 in any order.
4. After DL-5 (#13): record your viva (`VIVA_SCRIPT.md`) and post the link on #14.

The full dependency graph is in `docs/TEAM_PLAN.md`. Notion shows the live status.

## 4. Setup and run (exact commands)

```bash
git clone https://github.com/krishiv274/Signal2Space.git
```

```bash
cd Signal2Space
```

```bash
python3 -m venv .venv
```

```bash
source .venv/bin/activate
```

On Windows PowerShell, activate with `.venv\Scripts\Activate.ps1` instead.

```bash
python -m pip install -r requirements-dl.txt
```

```bash
python -m pytest -q tests
```

```bash
python scripts/run_dl_pipeline.py evaluate
```

`evaluate` re-scores the committed frozen checkpoints in about 30 seconds. The held-out numbers it prints must match `data/tables/dl_05_model_comparison.csv`. Open the notebooks with `jupyter notebook` from the repository root.

To work on your notebook, open it from `Deep Learning Pipeline/` and run all cells. `RETRAIN = False` reuses the committed checkpoint.

## 5. Branch, commit, push, PR

Your issue is **#10** (https://github.com/krishiv274/Signal2Space/issues/10). Your branch `dl/03-floor-imbalance-Koray-afk` **already exists on GitHub**. It was created from the integration branch of PR #7, so it contains all the DL code and you can start now.

1. **Get your branch.** If you already have a clone, skip the clone command and run `git fetch origin` instead.

```bash
git clone https://github.com/krishiv274/Signal2Space.git
```

```bash
cd Signal2Space
```

```bash
git fetch origin dl/03-floor-imbalance-Koray-afk
```

```bash
git switch dl/03-floor-imbalance-Koray-afk
```

2. **Work and commit in small steps.** Stage only the files you changed:

```bash
git add <files you changed>
```

```bash
git commit -m "DL-3: <what you did> (refs #10)"
```

3. **Push often.** This backs up your work, and nobody else uses your branch:

```bash
git push -u origin dl/03-floor-imbalance-Koray-afk
```

4. **When your work is done and PR #7 has been merged into `main`**, rebase on `main` and re-run the checks:

```bash
git fetch origin main
```

```bash
git rebase origin/main
```

```bash
python -m pytest -q tests
```

```bash
python scripts/run_dl_pipeline.py evaluate
```

```bash
git push --force-with-lease
```

Only ever force-push your own branch, never `main`. If #7 is not merged yet when you finish, open your PR as a **draft** (step 5) and rebase once it merges.

5. **Open the PR** into `main` on GitHub (the "Compare & pull request" button), or with the CLI:

```bash
gh pr create --base main --head dl/03-floor-imbalance-Koray-afk --title "[DL-3] Floor head: per-building errors and class-weighting ablation (DL_03)" --body "Closes #10" --reviewer krishiv274
```

In the PR body: keep `Closes #10`, paste the acceptance checklist from issue #10 with each item ticked, and paste the last lines of the `pytest` and `evaluate` output.

6. **Request a review** from `krishiv274` (Reviewers panel). Answer comments with new commits, set your Notion row to **In review**, and let Krishiv merge.


## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: signal2space_dl` in a notebook | Start Jupyter from the repository root, or check that the first cell found `ROOT`. The package lives in `src/`. |
| `pip` cannot find `torch==2.15.0` | Use Python 3.13 or 3.14 (64-bit). On Linux, install the CPU wheel from the PyTorch index first (`docs/DL_PIPELINE.md` §6). |
| `FileNotFoundError` for `trainingData.csv` | Put both CSVs in `data/raw/`. They are committed in the repository, so check that your clone is complete with `git status`. |
| `RuntimeError: ... changed after training; refusing held-out evaluation` | A checkpoint was modified. Restore it with `git checkout -- models/` and do not retrain committed models in place. |
| Metrics differ slightly from the docs after `RETRAIN = True` | Expected across machines and CPU/GPU kernels. Do not commit retrained shared checkpoints; revert with `git checkout -- models/ data/`. |
| `git push` is rejected (non-fast-forward) | Run `git fetch origin`, then `git rebase origin/main`, then `git push --force-with-lease`. Force-push your own branch only. |
| Merge conflict in a notebook | Keep `main`'s version of cells you do not own (`git checkout --theirs` or `--ours` per file), then re-run the notebook to regenerate outputs. |
| Cannot push at all (403), or you cannot be assigned | Ask Krishiv to add you as a collaborator with write access (Settings → Collaborators). |

## 7. Checklist before handing work to the integrator

- [ ] `python -m pytest -q tests` passes.
- [ ] `python scripts/run_dl_pipeline.py evaluate` runs, and the committed held-out numbers are unchanged unless your issue says otherwise.
- [ ] Your notebook runs top to bottom (Kernel → Restart & Run All), and its Findings cell is updated.
- [ ] Only files in your scope changed (`git diff --stat origin/main`). No raw data, `.venv`, or retrained shared checkpoints.
- [ ] The PR targets `main`, contains `Closes #<issue>`, and has the acceptance checklist ticked and the test output pasted.
- [ ] Review is requested from `krishiv274`, and the Notion status is set to **In review**.
- [ ] Your viva script's [placeholders] are filled with your final numbers.

## 8. What is in this ZIP

- `README_Abhiman.md`: this file
- `ISSUE_DL-3.md`: the GitHub issue text
- `VIVA_SCRIPT.md`: your viva recording script, 5 minutes maximum
- `reference_files/`: **read-only copies** of the files you will work with, taken from the integration branch. Always edit the real files in your repository clone, not these copies.
- `Deep Learning Pipeline/DL_03_floor_prediction.ipynb`
- `data/figures/dl_03_floor_heldout_confusion_matrix.png`
- `data/figures/dl_03_floor_training_curves.png`
- `data/tables/dl_03_floor_heldout_per_class.csv`
- `data/tables/dl_03_floor_metrics.csv`
- `docs/DL_PIPELINE.md`
- `requirements-dl.txt`
- `src/signal2space_dl/cli.py`
- `src/signal2space_dl/config.py`
- `src/signal2space_dl/train.py`
