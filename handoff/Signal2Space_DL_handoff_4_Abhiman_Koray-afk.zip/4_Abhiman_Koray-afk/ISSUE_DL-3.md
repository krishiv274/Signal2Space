# [DL-3] Floor head: per-building errors and class-weighting ablation (DL_03)

**ID:** DL-3 · **Step 2:** Parallel member work (start now on pre-created branches; PRs after DL-0 merges; DL-1 merges first)
**Owner:** Abhiman (@Koray-afk) · **Branch:** `dl/03-floor-imbalance-Koray-afk` · **Effort (estimate):** about 5–7 hours
**Blocked by:** #8 (DL-0)
**When to start:** Start now on your pre-created branch, in parallel with DL-1, DL-2 and DL-4; open the PR after DL-0 merges; merge after DL-1
**Tracker:** #6

## Goal
Floor is the weakest classification task (held-out 89.9%; floor 4 recall 74%). Quantify where the errors happen and test class weighting with a decision rule fixed in advance.

## Scope
- Run `DL_03_floor_prediction.ipynb` with `RETRAIN = False`.
- Break floor errors down by building and by true floor, for internal validation and held-out (descriptive). Save `data/tables/dl_03_floor_errors_by_building.csv`.
- Add the experiment `floor_only_weighted` to `config.EXPERIMENTS` and `EXPERIMENT_PREFIX` (prefix `dl_03_floor_weighted`), with `class_weighting=True` applied for that experiment only in `cli.run_train`. Train it with `python scripts/run_dl_pipeline.py train --experiments floor_only_weighted`.
- **Decision rule, fixed before you look at held-out results:** adopt weighting only if internal-validation macro F1 improves by at least 0.5 percentage points over `floor_only`. Then score held-out **once**, report it whatever the result, and record the decision in DL_03.

## Inputs
- `models/dl_03_floor_model.pt`
- `src/signal2space_dl/config.py`, `cli.py`, `train.py`
- DL_03 notebook

## Outputs
- New checkpoint `models/dl_03_floor_weighted_model.pt|json`
- Weighted-model metrics, per-class table and confusion matrix
- Error breakdown CSV and Findings in DL_03

## Acceptance criteria
- [ ] The existing four checkpoints are unchanged. The new experiment is additive.
- [ ] The decision is made from internal-validation numbers only and written down before the held-out row.
- [ ] `pytest` passes, and `evaluate --experiments floor_only floor_only_weighted` runs.

## Workflow
Work on `dl/03-floor-imbalance-Koray-afk` (pre-created from the integration branch). Commit with `DL-3: ... (refs #<this issue>)`, then push. Open a PR into `main` with `Closes #<this issue>` after DL-0 merges, and request review from @krishiv274.
Full step-by-step instructions: `Signal2Space_DL_handoff_4_Abhiman_Koray-afk.zip` (in `handoff/`) and `docs/TEAM_PLAN.md`.

Planner: https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
