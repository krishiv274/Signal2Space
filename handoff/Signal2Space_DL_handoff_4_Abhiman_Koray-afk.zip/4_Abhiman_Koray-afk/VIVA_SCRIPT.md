# Viva script

## Abhiman (@Koray-afk): Floor classification head, class imbalance and the weighting ablation
**Total planned length: 4:40** (limit 5:00). Square brackets mean: fill in from your own results before recording.

| Time | Section | What to say | What to show on screen |
|---|---|---|---|
| 0:00–0:35 (35 s) | My role | I own DL_03, floor prediction, the hardest classification task. | DL-3 issue; `DL_03_floor_prediction.ipynb` |
| 0:35–1:35 (60 s) | Model and the gap | The floor-only network reaches 97.4% on internal validation but 89.92% on held-out. AML shows the same gap, so the held-out data, recorded later with other phones, is genuinely harder. | `dl_03_floor_training_curves.png`; DL_03 metrics cell |
| 1:35–2:35 (60 s) | Where errors happen | Floor 4 exists only in building 2 and has the lowest recall, 74% on 39 rows. Many floor-1 rows are predicted as floor 2. [Quote your by-building table.] | `dl_03_floor_heldout_confusion_matrix.png`; `dl_03_floor_heldout_per_class.csv`; `dl_03_floor_errors_by_building.csv` |
| 2:35–3:50 (75 s) | Class-weighting ablation | I fixed the rule first: adopt weighting only if internal-validation macro F1 rises by at least 0.5 points. [State the result and decision.] Held-out was scored once afterwards. | Your DL-3 PR; weighted vs unweighted table in DL_03 |
| 3:50–4:40 (50 s) | Comparison and link | Unweighted DL floor is 89.92% against AML's 88.93%. The interval includes zero, so this is not a proven improvement. Floor errors also drive the larger coordinate errors in the hierarchy analysis. | `dl_05_hierarchical_breakdown.csv`; `dl_05_vs_aml_paired_bootstrap.csv` |

**One-line summary of your contribution:** Floor is the weakest classification task (held-out 89.9%; floor 4 recall 74%). Quantify where the errors happen and test class weighting with a decision rule fixed in advance. It connects to the full project as one stage of a single pipeline: DL_01 data, then DL_02–DL_04 heads, then DL_05 comparison with AML.

**Recording tips:** use 1080p screen capture and zoom the editor to about 125%. Open every file and tab before you start. Rehearse once with a timer and cut words rather than talking faster.

