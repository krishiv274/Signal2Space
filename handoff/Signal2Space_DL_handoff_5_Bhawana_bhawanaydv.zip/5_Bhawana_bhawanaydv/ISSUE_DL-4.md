# [DL-4] Coordinate head: error analysis and CRS/unit verification (DL_04)

**ID:** DL-4 · **Step 2:** Parallel member work (after DL-0 merges; DL-1 merges first)
**Owner:** Bhawana (@bhawanaydv) · **Branch:** `dl/04-coordinate-crs-bhawanaydv` · **Effort (estimate):** about 4–6 hours
**Blocked by:** DL-0 (DL-0)
**When to start:** Start after DL-0 is merged; parallel with DL-1, DL-2 and DL-3; merge after DL-1
**Tracker:** tracker issue

## Goal
Explain where coordinate error comes from and resolve the open question of coordinate units and CRS, without changing the reported metrics.

## Scope
- Run `DL_04_coordinate_prediction.ipynb` with `RETRAIN = False`.
- Compute error by building and floor for `coordinate_only`, `multitask` and AML (join `ml_05_aml_heldout_integrated_predictions.csv` on `ROW_ID`). Save `data/tables/dl_04_coordinate_error_by_building_floor.csv`.
- CRS check: apply the inverse Web-Mercator (EPSG:3857 to WGS84) formula to the coordinate ranges. Confirm whether they fall on Universitat Jaume I, Castellón (about 39.99° N, 0.07° W). Document the evidence and its limits.
- If EPSG:3857 is consistent, add an *estimated* ground-distance column, error × cos(latitude) (about ×0.77). Label it clearly as an estimate. The primary metrics stay in dataset units.
- Update the DL_04 Findings and `docs/DL_PIPELINE.md` §9 (CRS bullet).

## Inputs
- `data/tables/dl_04_coordinate_heldout_predictions.csv`, `dl_05_multitask_heldout_predictions.csv`, `ml_05_aml_heldout_integrated_predictions.csv`
- DL_04 notebook

## Outputs
- Error breakdown CSV
- CRS verification note
- Optional ground-distance estimate table

## Acceptance criteria
- [ ] No retraining, and the reported metrics are unchanged.
- [ ] The CRS conclusion states its evidence and remaining uncertainty.
- [ ] DL_04 runs top to bottom, and `pytest` passes.

## Workflow
Branch `dl/04-coordinate-crs-bhawanaydv` from `main` → commit referencing this issue → push → open PR into `main` with `Closes #<this issue>` → request review from @krishiv274.
Full step-by-step instructions: `Signal2Space_DL_handoff_5_Bhawana_bhawanaydv.zip` (in `handoff/`) and `docs/TEAM_PLAN.md`.

Planner: https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
