# Viva script

## Bhawana (@bhawanaydv): Coordinate regression head, error analysis and CRS/units
**Total planned length: 4:40** (limit 5:00). Square brackets mean: fill in from your own results before recording.

| Time | Section | What to say | What to show on screen |
|---|---|---|---|
| 0:00–0:35 (35 s) | My role | I own DL_04, coordinate regression, and the question of what the coordinate units really are. | DL-4 issue; `DL_04_coordinate_prediction.ipynb` |
| 0:35–1:35 (60 s) | Model and loss | The coordinate head outputs two numbers. Targets are centred and divided by 10, and the loss is Huber, so errors above about 10 units do not dominate the gradients. | `model.py::MultitaskLoss`; `dl_04_coordinate_training_curves.png` |
| 1:35–2:45 (70 s) | Result vs AML | The coordinate-only network gets a mean error of 10.51 against 11.58 for the Random Forest. The bootstrap interval excludes zero. The DL tail is better (p90 21.3 against 24.4), but the Random Forest has the lower median. | DL_04 comparison cell; `dl_05_heldout_error_cdf.png`; `dl_05_vs_aml_paired_bootstrap.csv` |
| 2:45–3:35 (50 s) | Where error happens | [Quote your by-building and by-floor table.] Rows whose floor is predicted wrong have roughly double the coordinate error. | `dl_04_coordinate_error_by_building_floor.csv`; `dl_04_coordinate_errors.png` |
| 3:35–4:40 (65 s) | CRS verification | Converting from Web-Mercator, the points land [state result]. Web-Mercator inflates distances by about 1/cos(latitude), so ground error is about 0.77 times the reported numbers. We report dataset units and label this as an estimate. | Your CRS note in DL_04 and `docs/DL_PIPELINE.md` §9; your DL-4 PR |

**One-line summary of your contribution:** Explain where coordinate error comes from and resolve the open question of coordinate units and CRS, without changing the reported metrics. It connects to the full project as one stage of a single pipeline: DL_01 data, then DL_02–DL_04 heads, then DL_05 comparison with AML.

**Recording tips:** use 1080p screen capture and zoom the editor to about 125%. Open every file and tab before you start. Rehearse once with a timer and cut words rather than talking faster.

