# [DL-5] Final integration: re-run, reconcile results, update report/PPT, tag release

**ID:** DL-5 · **Step 3:** Final integration (after DL-1 to DL-4 merge)
**Owner:** Krishiv (@krishiv274) · **Branch:** `dl/05-integration-krishiv274` · **Effort (estimate):** about 4–6 hours
**Blocked by:** #12 (DL-1), #9 (DL-2), #10 (DL-3), #11 (DL-4)
**When to start:** Start after DL-1 to DL-4 are merged
**Tracker:** #6

## Goal
Validate the combined work on `main`, keep every results statement consistent, and produce the final report material.

## Scope
- Branch from the updated `main`. Run `pytest`, `python scripts/run_dl_pipeline.py evaluate` (including `floor_only_weighted` if DL-3 added it), and all ten notebooks (ML_01 to ML_05 are optional, because they are unchanged).
- Reconcile `dl_05_model_comparison.csv`, `README.md`, `docs/DL_PIPELINE.md` §8 and each notebook's Findings. Every number quoted in prose must match a table.
- Add a DL section to `reports/AML_Project_Report.tex` (and rebuild the PDF) and to the PPTX: architecture, data flow, comparison table and limitations.
- Tag `v2.0-dl` on `main` after merge, and close the tracker.

## Inputs
- Merged DL-1 to DL-4 work
- `reports/`

## Outputs
- Reconciled docs and results
- Updated report and PPT
- Tag `v2.0-dl`

## Acceptance criteria
- [ ] Every member's PR is merged, and `main` passes tests and `evaluate`.
- [ ] There are no contradictory numbers between the README, docs, notebooks and report.
- [ ] Results are claimed only for the supplied split, and all caveats are retained.

## Workflow
Work on `dl/05-integration-krishiv274` (create it from the updated `main`). Commit with `DL-5: ... (refs #<this issue>)`, then push. Open a PR into `main` with `Closes #<this issue>`, and request review from the four members.
Full step-by-step instructions: `Signal2Space_DL_handoff_1_Krishiv_krishiv274.zip` (in `handoff/`) and `docs/TEAM_PLAN.md`.

Planner: https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
