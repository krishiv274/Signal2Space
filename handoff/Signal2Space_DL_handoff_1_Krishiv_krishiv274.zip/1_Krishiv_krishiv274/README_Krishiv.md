# Signal2Space DL handoff: Krishiv (`krishiv274`)

**Role:** Integration owner
**Repository:** https://github.com/krishiv274/Signal2Space
**Planner:** https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
**Team plan:** `docs/TEAM_PLAN.md`
**Technical reference:** `docs/DL_PIPELINE.md` (also in `reference_files/`)

## 1. Project context (what already exists)

Signal2Space predicts building, floor and 2D position from Wi-Fi fingerprints (UJIIndoorLoc: 520 access points, where `100` means not detected).

**Phase 1 (AML).** Five Random Forest notebooks. Held-out results: building 99.73%, floor 88.93%, mean coordinate error 11.58 dataset units.

**Phase 2 (DL).** Already implemented and run end to end on branch `claude/peaceful-shannon-o1t6j8`:
- a PyTorch shared-trunk network with building, floor and coordinate heads;
- three single-task ablations;
- the AML-identical split, train-only preprocessing, early stopping and SHA-checked frozen evaluation.

**Held-out DL results.**
- Multitask: building 99.91%, floor 89.56%, mean error 12.00.
- Best single-task: building 99.82%, floor 89.92%, mean error 10.51.

Your job is to **verify, analyse and extend** your part, not to re-implement it.

## 2. Your assignment

### [DL-0] Review, verify on macOS and merge the DL integration PR
- **ID:** DL-0
- **Step:** 1 (Integrate the implemented pipeline (start now))
- **Branch:** `claude/peaceful-shannon-o1t6j8`
- **Effort (estimate):** about 2–3 hours
- **Depends on:** none
- **When to start:** Start now

**Goal.** Publish and merge the implemented DL pipeline (package, notebooks, full-run outputs and docs) after verifying it on the team's macOS / Python 3.14 environment. Preserve existing local work.

**Scope**
- Publish the integration branch: push `claude/peaceful-shannon-o1t6j8`. If it is not already on GitHub, fetch it from `signal2space-dl-integration.bundle` first (steps in your handoff README).
- Preserve local work before checking out the branch. Commit the modified `reports/AML_Project_PPT .pptx` on its own branch (`docs/aml-ppt-update-krishiv274`).
- Keep the local untracked `src/signal2space_dl/pipeline.py` and diff it against the new modules (`data.py`, `model.py`, `train.py`, `evaluate.py`). Port anything it does that the package does not, as a separate commit. Do not delete it unreviewed.
- Install `requirements-dl.txt` on Python 3.14 (macOS). Run `pytest`, `python scripts/run_dl_pipeline.py evaluate` and the five DL notebooks.
- Open the PR into `main`, request review from all four members, address comments and merge.
- Run `scripts/create_github_plan.sh` (needs the `gh` CLI) to create the labels, the DL-1 to DL-6 issues and the member branches.

**Inputs**
- Integration branch or bundle
- Local `src/signal2space_dl/pipeline.py` and modified PPTX (on your Mac only)

**Outputs**
- Merged integration PR
- PPTX change preserved on its own branch
- GitHub issues and branches created
- Note in the PR on whether `evaluate` reproduced the committed metrics on macOS

**Acceptance criteria**
- [ ] `python -m pytest -q tests` passes on macOS with Python 3.14.
- [ ] `python scripts/run_dl_pipeline.py evaluate` reproduces the held-out rows of `data/tables/dl_05_model_comparison.csv` to 4 decimal places, or the differences are recorded in the PR.
- [ ] The local `pipeline.py` and PPTX changes are preserved and not overwritten.
- [ ] The PR is merged into `main`, and the DL-1 to DL-6 issues and branches exist.

### [DL-5] Final integration: re-run, reconcile results, update report/PPT, tag release
- **ID:** DL-5
- **Step:** 3 (Final integration (after DL-1 to DL-4 merge))
- **Branch:** `dl/05-integration-krishiv274`
- **Effort (estimate):** about 4–6 hours
- **Depends on:** DL-1, DL-2, DL-3, DL-4
- **When to start:** Start after DL-1 to DL-4 are merged

**Goal.** Validate the combined work on `main`, keep every results statement consistent, and produce the final report material.

**Scope**
- Branch from the updated `main`. Run `pytest`, `python scripts/run_dl_pipeline.py evaluate` (including `floor_only_weighted` if DL-3 added it), and all ten notebooks (ML_01 to ML_05 are optional, because they are unchanged).
- Reconcile `dl_05_model_comparison.csv`, `README.md`, `docs/DL_PIPELINE.md` §8 and each notebook's Findings. Every number quoted in prose must match a table.
- Add a DL section to `reports/AML_Project_Report.tex` (and rebuild the PDF) and to the PPTX: architecture, data flow, comparison table and limitations.
- Tag `v2.0-dl` on `main` after merge, and close the tracker.

**Inputs**
- Merged DL-1 to DL-4 work
- `reports/`

**Outputs**
- Reconciled docs and results
- Updated report and PPT
- Tag `v2.0-dl`

**Acceptance criteria**
- [ ] Every member's PR is merged, and `main` passes tests and `evaluate`.
- [ ] There are no contradictory numbers between the README, docs, notebooks and report.
- [ ] Results are claimed only for the supplied split, and all caveats are retained.

### [DL-6] Viva recordings (≤5 min each) for all five members
- **ID:** DL-6
- **Step:** 4 (Viva recordings (after DL-5))
- **Branch:** `(no branch; links are posted as issue comments)`
- **Effort (estimate):** about 1–2 hours per member
- **Depends on:** DL-5
- **When to start:** Rehearse any time; record after DL-5 so the numbers are final

**Goal.** Each member records a viva of at most five minutes using `docs/VIVA_SCRIPTS.md`. Krishiv coordinates and checks that every recording is consistent with the final results.

**Scope**
- Each member follows their script section in `docs/VIVA_SCRIPTS.md` and screen-records their part (5 minutes maximum).
- If DL-5 changed any number, update the script before recording.
- Post each recording link as a comment on this issue. Krishiv ticks the checklist below.

**Inputs**
- `docs/VIVA_SCRIPTS.md`
- Final merged repository

**Outputs**
- Five recording links

**Acceptance criteria**
- [ ] 5 recordings, each 5:00 or shorter.
- [ ] The numbers spoken match `data/tables/dl_05_model_comparison.csv` on `main`.
- [ ] Checklist: Krishiv ☐, Gargi ☐, Agrima ☐, Abhiman ☐, Bhawana ☐.


## 3. Order of work and dependencies

1. DL-0: preserve your local work, publish and verify the branch, merge it, and create the issues and branches.
2. Unblock the members, review their PRs, and merge DL-1 first, then DL-2, DL-3 and DL-4.
3. DL-5: final integration.
4. DL-6: collect the five viva recordings.

The full dependency graph is in `docs/TEAM_PLAN.md`. Notion shows the live status.

## 4. Setup and run (exact commands)

```bash
git clone https://github.com/krishiv274/Signal2Space.git
```

```bash
cd Signal2Space
```

```bash
python3 -m venv .venv
```

```bash
source .venv/bin/activate
```

On Windows PowerShell, activate with `.venv\Scripts\Activate.ps1` instead.

```bash
python -m pip install -r requirements-dl.txt
```

```bash
python -m pytest -q tests
```

```bash
python scripts/run_dl_pipeline.py evaluate
```

`evaluate` re-scores the committed frozen checkpoints in about 30 seconds. The held-out numbers it prints must match `data/tables/dl_05_model_comparison.csv`. Open the notebooks with `jupyter notebook` from the repository root.

To work on your notebook, open it from `Deep Learning Pipeline/` and run all cells. `RETRAIN = False` reuses the committed checkpoint.

## 5. Branch, commit, push, PR

### A. Preserve your local work first (DL-0)

1. Commit the modified PowerPoint on its own branch:

```bash
cd ~/Desktop/Signal2Space
```

```bash
git status
```

```bash
git switch -c docs/aml-ppt-update-krishiv274
```

```bash
git add "reports/AML_Project_PPT .pptx"
```

```bash
git commit -m "Update AML presentation"
```

```bash
git push -u origin docs/aml-ppt-update-krishiv274
```

2. Leave the untracked `src/signal2space_dl/pipeline.py` where it is. The integration branch adds other files in that folder (it has no `pipeline.py`), so checking it out will not overwrite your file. Keep a backup anyway:

```bash
cp src/signal2space_dl/pipeline.py ~/Desktop/pipeline_backup.py
```

### B. Publish the integration branch

If `claude/peaceful-shannon-o1t6j8` is not on GitHub yet, use the bundle file delivered with this handoff (`signal2space-dl-integration.bundle`, attached separately):

```bash
git switch main
```

```bash
git pull origin main
```

```bash
git bundle verify ~/Downloads/signal2space-dl-integration.bundle
```

```bash
git fetch ~/Downloads/signal2space-dl-integration.bundle claude/peaceful-shannon-o1t6j8:claude/peaceful-shannon-o1t6j8
```

```bash
git push -u origin claude/peaceful-shannon-o1t6j8
```

If it is already on GitHub:

```bash
git fetch origin claude/peaceful-shannon-o1t6j8
```

```bash
git switch claude/peaceful-shannon-o1t6j8
```

### C. Verify, open the PR, merge

```bash
git switch claude/peaceful-shannon-o1t6j8
```

Open your untracked `src/signal2space_dl/pipeline.py` side by side with `data.py`, `model.py`, `train.py` and `evaluate.py`. Port anything it does that the package does not (for example a different input or loss), as a separate commit with its own tests. Either commit `pipeline.py` deliberately or move it out of the package; do not leave it untracked inside `src/`.

```bash
python -m pytest -q tests
```

```bash
python scripts/run_dl_pipeline.py evaluate
```

```bash
gh pr create --base main --head claude/peaceful-shannon-o1t6j8 --title "[DL-0] Add PyTorch multitask DL pipeline, full run and team handoff" --body "Closes #<DL-0>. See docs/DL_PIPELINE.md and docs/TEAM_PLAN.md." --reviewer gigabyte2024,slayplayagrima,Koray-afk,bhawanaydv
```

You can also open the PR in the browser (base `main`). After review, merge it with **Squash and merge**.

### D. Create the issues and branches

```bash
bash scripts/create_github_plan.sh issues
```

Commit the generated `docs/github_plan/ISSUE_NUMBERS.md`, then copy the numbers into the Notion **Issue** column.

```bash
bash scripts/create_github_plan.sh branches
```

### E. Final integration (DL-5), after DL-1 to DL-4 are merged

```bash
git switch main
```

```bash
git pull origin main
```

```bash
git switch -c dl/05-integration-krishiv274
```

Then re-run, reconcile and update the report, and commit with the message `DL-5: ... (refs #<DL-5>)`.

```bash
git push -u origin dl/05-integration-krishiv274
```

Open the PR with `Closes #<DL-5>` and merge it. Then tag the release:

```bash
git tag -a v2.0-dl -m "Signal2Space DL phase"
```

```bash
git push origin v2.0-dl
```


## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: signal2space_dl` in a notebook | Start Jupyter from the repository root, or check that the first cell found `ROOT`. The package lives in `src/`. |
| `pip` cannot find `torch==2.15.0` | Use Python 3.13 or 3.14 (64-bit). On Linux, install the CPU wheel from the PyTorch index first (`docs/DL_PIPELINE.md` §6). |
| `FileNotFoundError` for `trainingData.csv` | Put both CSVs in `data/raw/`. They are committed in the repository, so check that your clone is complete with `git status`. |
| `RuntimeError: ... changed after training; refusing held-out evaluation` | A checkpoint was modified. Restore it with `git checkout -- models/` and do not retrain committed models in place. |
| Metrics differ slightly from the docs after `RETRAIN = True` | Expected across machines and CPU/GPU kernels. Do not commit retrained shared checkpoints; revert with `git checkout -- models/ data/`. |
| `git push` is rejected (non-fast-forward) | Run `git fetch origin`, then `git rebase origin/main`, then `git push --force-with-lease`. Force-push your own branch only. |
| Merge conflict in a notebook | Keep `main`'s version of cells you do not own (`git checkout --theirs` or `--ours` per file), then re-run the notebook to regenerate outputs. |
| Cannot push at all (403) | Ask Krishiv to add you as a collaborator with write access. |

## 7. Checklist before handing work to the integrator

- [ ] `python -m pytest -q tests` passes.
- [ ] `python scripts/run_dl_pipeline.py evaluate` runs, and the committed held-out numbers are unchanged unless your issue says otherwise.
- [ ] Your notebook runs top to bottom (Kernel → Restart & Run All), and its Findings cell is updated.
- [ ] Only files in your scope changed (`git diff --stat origin/main`). No raw data, `.venv`, or retrained shared checkpoints.
- [ ] The PR targets `main`, contains `Closes #<issue>`, and has the acceptance checklist ticked and the test output pasted.
- [ ] Review is requested from `krishiv274`, and the Notion status is set to **In review**.
- [ ] Your viva script's [placeholders] are filled with your final numbers.

## 8. What is in this ZIP

- `README_Krishiv.md`: this file
- `ISSUE_DL-0.md`, `ISSUE_DL-5.md`, `ISSUE_DL-6.md`: the GitHub issue text
- `VIVA_SCRIPT.md`: your viva recording script, 5 minutes maximum
- `reference_files/`: **read-only copies** of the files you will work with, taken from the integration branch. Always edit the real files in your repository clone, not these copies.
- `Deep Learning Pipeline/DL_05_multitask_integration_evaluation.ipynb`
- `README.md`
- `data/figures/dl_05_heldout_model_comparison.png`
- `data/tables/dl_05_hierarchical_breakdown.csv`
- `data/tables/dl_05_model_comparison.csv`
- `data/tables/dl_05_vs_aml_paired_bootstrap.csv`
- `docs/DL_PIPELINE.md`
- `docs/TEAM_PLAN.md`
- `docs/VIVA_SCRIPTS.md`
- `requirements-dl.txt`
- `scripts/create_github_plan.sh`
- `scripts/run_dl_pipeline.py`
- `src/signal2space_dl/__init__.py`
- `src/signal2space_dl/cli.py`
- `src/signal2space_dl/config.py`
- `src/signal2space_dl/data.py`
- `src/signal2space_dl/evaluate.py`
- `src/signal2space_dl/model.py`
- `src/signal2space_dl/plots.py`
- `src/signal2space_dl/train.py`
- `src/signal2space_dl/cli.py`
