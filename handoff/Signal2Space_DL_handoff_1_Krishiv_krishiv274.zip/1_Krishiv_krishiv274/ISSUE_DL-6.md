# [DL-6] Viva recordings (≤5 min each) for all five members

**ID:** DL-6 · **Step 4:** Viva recordings (after DL-5)
**Owner:** Krishiv (@krishiv274) · **Branch:** `(no branch; links are posted as issue comments)` · **Effort (estimate):** about 1–2 hours per member
**Blocked by:** #13 (DL-5)
**When to start:** Rehearse any time; record after DL-5 so the numbers are final
**Tracker:** #6

## Goal
Each member records a viva of at most five minutes using `docs/VIVA_SCRIPTS.md`. Krishiv coordinates and checks that every recording is consistent with the final results.

## Scope
- Each member follows their script section in `docs/VIVA_SCRIPTS.md` and screen-records their part (5 minutes maximum).
- If DL-5 changed any number, update the script before recording.
- Post each recording link as a comment on this issue. Krishiv ticks the checklist below.

## Inputs
- `docs/VIVA_SCRIPTS.md`
- Final merged repository

## Outputs
- Five recording links

## Acceptance criteria
- [ ] 5 recordings, each 5:00 or shorter.
- [ ] The numbers spoken match `data/tables/dl_05_model_comparison.csv` on `main`.
- [ ] Checklist: Krishiv ☐, Gargi ☐, Agrima ☐, Abhiman ☐, Bhawana ☐.

## Workflow
No branch. Each member posts their recording link as a comment on this issue.
Full step-by-step instructions: `Signal2Space_DL_handoff_1_Krishiv_krishiv274.zip` (in `handoff/`) and `docs/TEAM_PLAN.md`.

Planner: https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
