# Viva script

## Krishiv (@krishiv274): Project overview, DL architecture, integration and final AML comparison
**Total planned length: 4:55** (limit 5:00). Square brackets mean: fill in from your own results before recording.

| Time | Section | What to say | What to show on screen |
|---|---|---|---|
| 0:00–0:40 (40 s) | Problem and data | Signal2Space predicts building, floor and position from Wi-Fi fingerprints in UJIIndoorLoc: 520 access points, where 100 means not detected. We have about 20,000 training fingerprints and 1,111 held-out ones. | README top section; `data/figures/ml_01_coordinate_labels_eda.png` |
| 0:40–1:20 (40 s) | Phase 1 recap | Phase 1 was Random Forests with a group split. On held-out data they reached 99.73% building, 88.93% floor and 11.58 units mean coordinate error. | `data/tables/ml_05_aml_summary_metrics.csv`; README results table |
| 1:20–2:30 (70 s) | DL architecture | Each fingerprint becomes 1,040 inputs: 520 standardised strengths and 520 'was it heard' flags. A shared two-layer trunk feeds three heads. The loss adds two cross-entropies and a Huber loss on coordinates divided by 10, which keeps the three terms on a similar scale. | `src/signal2space_dl/model.py` (MultitaskMLP, MultitaskLoss); `docs/DL_PIPELINE.md` §4 diagram |
| 2:30–3:30 (60 s) | Integration and discipline | My job was integration. DL uses exactly the AML split; we verify the row IDs match. Every model is frozen on internal validation, and evaluation refuses to run if the checkpoint hash changed. | `evaluate.py::evaluate_experiment` (SHA check); `dl_01_split_parity.json`; GitHub PR for DL-0 and the tracker issue |
| 3:30–4:30 (60 s) | Results vs AML | Multitask: 99.91% building, 89.56% floor, 995 of 1,111 rows with both correct, against 986 for AML. The coordinate-only network is the only resolved win: mean error 10.51 against 11.58. Sharing the trunk hurt coordinates. | `DL_05` notebook comparison table; `dl_05_heldout_model_comparison.png`; `dl_05_vs_aml_paired_bootstrap.csv` |
| 4:30–4:55 (25 s) | Limits and close | These hold for the supplied split only. The CRS is unconfirmed and we used one seed. Next steps are a multi-seed run and tuning the coordinate weight on internal validation. | `docs/DL_PIPELINE.md` §9 |

**One-line summary of your contribution:** Review, verify and merge the integration PR #7, which holds the implemented DL pipeline (package, notebooks, full-run outputs, docs and handoff). Verify it on the team's macOS / Python 3.14 environment and preserve existing local work. It connects to the full project as one stage of a single pipeline: DL_01 data, then DL_02–DL_04 heads, then DL_05 comparison with AML.

**Recording tips:** use 1080p screen capture and zoom the editor to about 125%. Open every file and tab before you start. Rehearse once with a timer and cut words rather than talking faster.

