# Viva script

## Gargi (@gigabyte2024): Data preparation, leakage controls and the data-audit tests
**Total planned length: 4:40** (limit 5:00). Square brackets mean: fill in from your own results before recording.

| Time | Section | What to say | What to show on screen |
|---|---|---|---|
| 0:00–0:35 (35 s) | My role | I own DL_01: turning the raw CSVs into network inputs without leaking held-out information. | DL-1 issue on GitHub; `DL_01_data_preparation.ipynb` title cell |
| 0:35–1:35 (60 s) | Schema and missing signals | We validate all 529 columns. About 96.5% of signal values are 100, which means not detected. We fill those below the weakest real reading and add a presence flag, so the network can tell 'absent' from 'weak'. | DL_01 section 1 output (data-quality table); `data.py::validate_schema`, `Preprocessor.transform` |
| 1:35–2:40 (65 s) | Split and leakage control | We group by building, floor and space, so a reference space never sits in both internal train and validation. The split is identical to AML's, row for row. Every statistic is fitted on the 16,085 internal-train rows only. | DL_01 section 2 (split summary, parity = true); `data.py::make_group_split` |
| 2:40–3:50 (70 s) | Audit tests | My tests run on the real files and fail if any of these guarantees break: row counts, no shared groups, matching row IDs, and fitted parameters untouched by held-out data. | `tests/test_dl_data_real.py`, run with `pytest -q`; your DL-1 PR |
| 3:50–4:40 (50 s) | Findings and link to the project | I also counted identical fingerprints across partitions [quote your number]. That is why our results describe this split, not unseen locations. Every later notebook relies on this preparation. | `dl_01_fingerprint_overlap.csv`; `dl_01_input_representation.png` |

**One-line summary of your contribution:** Prove, with automated tests on the real CSVs, that the DL split and preprocessing are leakage-free and match AML. Document the audit. It connects to the full project as one stage of a single pipeline: DL_01 data, then DL_02–DL_04 heads, then DL_05 comparison with AML.

**Recording tips:** use 1080p screen capture and zoom the editor to about 125%. Open every file and tab before you start. Rehearse once with a timer and cut words rather than talking faster.

