# [DL-1] Data & leakage audit: real-data tests for DL_01 split and preprocessing

**ID:** DL-1 · **Step 2:** Parallel member work (start now on pre-created branches; PRs after DL-0 merges; DL-1 merges first)
**Owner:** Gargi (@gigabyte2024) · **Branch:** `dl/01-data-audit-gigabyte2024` · **Effort (estimate):** about 4–6 hours
**Blocked by:** #8 (DL-0)
**When to start:** Start now on your pre-created branch; open the PR into main after DL-0 merges; merges first in step 2
**Tracker:** #6

## Goal
Prove, with automated tests on the real CSVs, that the DL split and preprocessing are leakage-free and match AML. Document the audit.

## Scope
- Run `DL_01_data_preparation.ipynb` and read `src/signal2space_dl/data.py`.
- Add `tests/test_dl_data_real.py`, skipped automatically when `data/raw/*.csv` is missing. It should assert: 19,937 and 1,111 rows; the schema passes; internal split sizes are 16,085 and 3,852; no `BUILDINGID_FLOOR_SPACEID` group appears in both internal splits; internal-validation `ROW_ID`s equal those in `data/tables/ml_02_building_internal_validation_predictions.csv`; `Preprocessor.fit_rows == 16085`; transforming held-out data leaves the fitted parameters unchanged.
- Count fingerprints (identical WAP vectors) shared between internal-train and internal-validation, and between training and held-out. Report the counts descriptively; do **not** change the split.
- Write the results in the DL_01 Findings cell and add a short "Data audit" subsection to `docs/DL_PIPELINE.md` §3.

## Inputs
- `data/raw/trainingData.csv`, `data/raw/validationData.csv`
- `src/signal2space_dl/data.py`
- `data/tables/ml_02_building_internal_validation_predictions.csv`

## Outputs
- `tests/test_dl_data_real.py`
- `data/tables/dl_01_fingerprint_overlap.csv`
- Updated DL_01 findings and `docs/DL_PIPELINE.md` §3

## Acceptance criteria
- [ ] `python -m pytest -q tests` passes. The new tests run when the data is present and are skipped otherwise.
- [ ] The split, the preprocessing code and the committed checkpoints are unchanged (`evaluate` output is identical).
- [ ] The overlap counts are reported with a one-sentence interpretation.

## Workflow
Work on `dl/01-data-audit-gigabyte2024` (pre-created from the integration branch). Commit with `DL-1: ... (refs #<this issue>)`, then push. Open a PR into `main` with `Closes #<this issue>` after DL-0 merges, and request review from @krishiv274.
Full step-by-step instructions: `Signal2Space_DL_handoff_2_Gargi_gigabyte2024.zip` (in `handoff/`) and `docs/TEAM_PLAN.md`.

Planner: https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
