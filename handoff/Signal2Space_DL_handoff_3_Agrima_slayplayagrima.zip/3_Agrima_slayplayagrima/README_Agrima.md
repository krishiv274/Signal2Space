# Signal2Space DL handoff: Agrima (`slayplayagrima`)

**Role:** Building head & robustness (DL_02)
**Repository:** https://github.com/krishiv274/Signal2Space
**Planner:** https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
**Team plan:** `docs/TEAM_PLAN.md`
**Technical reference:** `docs/DL_PIPELINE.md` (also in `reference_files/`)

## 1. Project context (what already exists)

Signal2Space predicts building, floor and 2D position from Wi-Fi fingerprints (UJIIndoorLoc: 520 access points, where `100` means not detected).

**Phase 1 (AML).** Five Random Forest notebooks. Held-out results: building 99.73%, floor 88.93%, mean coordinate error 11.58 dataset units.

**Phase 2 (DL).** Already implemented and run end to end on branch `claude/peaceful-shannon-o1t6j8`:
- a PyTorch shared-trunk network with building, floor and coordinate heads;
- three single-task ablations;
- the AML-identical split, train-only preprocessing, early stopping and SHA-checked frozen evaluation.

**Held-out DL results.**
- Multitask: building 99.91%, floor 89.56%, mean error 12.00.
- Best single-task: building 99.82%, floor 89.92%, mean error 10.51.

Your job is to **verify, analyse and extend** your part, not to re-implement it.

## 2. Your assignment

### [DL-2] Building head: error review and missing-AP robustness (DL_02)
- **ID:** DL-2
- **Step:** 2 (Parallel member work (after DL-0 merges; DL-1 merges first))
- **Branch:** `dl/02-building-robustness-slayplayagrima`
- **Effort (estimate):** about 4–6 hours
- **Depends on:** DL-0
- **When to start:** Start after DL-0 is merged; parallel with DL-1, DL-3 and DL-4; merge after DL-1

**Goal.** Explain the building model's remaining errors and measure how accuracy degrades when detected access points go missing.

**Scope**
- Run `DL_02_building_prediction.ipynb` with `RETRAIN = False`.
- Inspect the 2 held-out errors of `building_only` (both are true building 0 predicted as 1). Report `PHONEID`, `USERID`, the number of detected WAPs and the predicted probabilities, joining `dl_02_building_heldout_predictions.csv` to `data/raw/validationData.csv` on `ROW_ID`.
- Add `mask_detected_aps(X, fraction, rng)` to `src/signal2space_dl/evaluate.py`. It sets the given fraction of *detected* APs per row to the missing state: presence flag 0 and the preprocessor's fill value. Add a unit test for it.
- Robustness experiment on **internal validation only**: for fractions {0, 0.1, 0.2, 0.3, 0.5} and 5 seeds, measure building accuracy of the `building_only` and `multitask` checkpoints. Save `data/tables/dl_02_building_ap_masking_robustness.csv` and `data/figures/dl_02_building_ap_masking_robustness.png`, and add them to DL_02.

**Inputs**
- `models/dl_02_building_model.pt`, `models/dl_05_multitask_model.pt`
- `src/signal2space_dl/evaluate.py`
- DL_02 notebook

**Outputs**
- `mask_detected_aps` plus its test
- Robustness CSV and figure
- Error-review table and Findings in DL_02

**Acceptance criteria**
- [ ] No retraining, and the committed checkpoints are unchanged.
- [ ] The robustness experiment uses internal validation only. The CSV has mean and standard deviation over the 5 seeds for each fraction and model.
- [ ] `pytest` passes and DL_02 runs top to bottom without errors.


## 3. Order of work and dependencies

1. Now: set up the environment (below), read `docs/DL_PIPELINE.md`, run `evaluate`, and open your notebook.
2. After DL-0 is merged: switch to your branch and do the scope items in order.
3. Open your PR. If you are not Gargi, merge after DL-1; rebase on `main` first.
4. After DL-5: record your viva (`VIVA_SCRIPT.md`).

The full dependency graph is in `docs/TEAM_PLAN.md`. Notion shows the live status.

## 4. Setup and run (exact commands)

```bash
git clone https://github.com/krishiv274/Signal2Space.git
```

```bash
cd Signal2Space
```

```bash
python3 -m venv .venv
```

```bash
source .venv/bin/activate
```

On Windows PowerShell, activate with `.venv\Scripts\Activate.ps1` instead.

```bash
python -m pip install -r requirements-dl.txt
```

```bash
python -m pytest -q tests
```

```bash
python scripts/run_dl_pipeline.py evaluate
```

`evaluate` re-scores the committed frozen checkpoints in about 30 seconds. The held-out numbers it prints must match `data/tables/dl_05_model_comparison.csv`. Open the notebooks with `jupyter notebook` from the repository root.

To work on your notebook, open it from `Deep Learning Pipeline/` and run all cells. `RETRAIN = False` reuses the committed checkpoint.

## 5. Branch, commit, push, PR

Replace `<N>` with your issue number. Find it in `docs/github_plan/ISSUE_NUMBERS.md` on `main`, or search GitHub issues for `[DL-2]`.

1. **Wait until DL-0 is merged into `main`** (check the Notion planner or the tracker issue). Get the latest code:

```bash
cd Signal2Space
```

```bash
git switch main
```

```bash
git pull origin main
```

2. **Switch to your branch.** Krishiv creates it with the script. If it already exists:

```bash
git fetch origin dl/02-building-robustness-slayplayagrima
```

```bash
git switch dl/02-building-robustness-slayplayagrima
```

If it does not exist yet, create it yourself from `main`:

```bash
git switch -c dl/02-building-robustness-slayplayagrima
```

3. **Work and commit in small steps.** Stage only the files you changed:

```bash
git add <files you changed>
```

```bash
git commit -m "DL-2: <what you did> (refs #<N>)"
```

4. **Before opening the PR**, update from `main` and re-run the checks:

```bash
git fetch origin main
```

```bash
git rebase origin/main
```

```bash
python -m pytest -q tests
```

```bash
python scripts/run_dl_pipeline.py evaluate
```

5. **Push your branch:**

```bash
git push -u origin dl/02-building-robustness-slayplayagrima
```

After a rebase, if the branch was already pushed:

```bash
git push --force-with-lease
```

Only ever force-push your own branch, never `main`.

6. **Open the PR** into `main` on GitHub (the "Compare & pull request" button), or with the CLI:

```bash
gh pr create --base main --head dl/02-building-robustness-slayplayagrima --title "[DL-2] Building head: error review and missing-AP robustness (DL_02)" --body "Closes #<N>" --reviewer krishiv274
```

In the PR body: write `Closes #<N>`, paste the acceptance checklist with each item ticked, and paste the last lines of the `pytest` and `evaluate` output.

7. **Request a review** from `krishiv274` (Reviewers panel), answer the comments with new commits, and let Krishiv merge.


## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: signal2space_dl` in a notebook | Start Jupyter from the repository root, or check that the first cell found `ROOT`. The package lives in `src/`. |
| `pip` cannot find `torch==2.15.0` | Use Python 3.13 or 3.14 (64-bit). On Linux, install the CPU wheel from the PyTorch index first (`docs/DL_PIPELINE.md` §6). |
| `FileNotFoundError` for `trainingData.csv` | Put both CSVs in `data/raw/`. They are committed in the repository, so check that your clone is complete with `git status`. |
| `RuntimeError: ... changed after training; refusing held-out evaluation` | A checkpoint was modified. Restore it with `git checkout -- models/` and do not retrain committed models in place. |
| Metrics differ slightly from the docs after `RETRAIN = True` | Expected across machines and CPU/GPU kernels. Do not commit retrained shared checkpoints; revert with `git checkout -- models/ data/`. |
| `git push` is rejected (non-fast-forward) | Run `git fetch origin`, then `git rebase origin/main`, then `git push --force-with-lease`. Force-push your own branch only. |
| Merge conflict in a notebook | Keep `main`'s version of cells you do not own (`git checkout --theirs` or `--ours` per file), then re-run the notebook to regenerate outputs. |
| Cannot push at all (403) | Ask Krishiv to add you as a collaborator with write access. |

## 7. Checklist before handing work to the integrator

- [ ] `python -m pytest -q tests` passes.
- [ ] `python scripts/run_dl_pipeline.py evaluate` runs, and the committed held-out numbers are unchanged unless your issue says otherwise.
- [ ] Your notebook runs top to bottom (Kernel → Restart & Run All), and its Findings cell is updated.
- [ ] Only files in your scope changed (`git diff --stat origin/main`). No raw data, `.venv`, or retrained shared checkpoints.
- [ ] The PR targets `main`, contains `Closes #<issue>`, and has the acceptance checklist ticked and the test output pasted.
- [ ] Review is requested from `krishiv274`, and the Notion status is set to **In review**.
- [ ] Your viva script's [placeholders] are filled with your final numbers.

## 8. What is in this ZIP

- `README_Agrima.md`: this file
- `ISSUE_DL-2.md`: the GitHub issue text
- `VIVA_SCRIPT.md`: your viva recording script, 5 minutes maximum
- `reference_files/`: **read-only copies** of the files you will work with, taken from the integration branch. Always edit the real files in your repository clone, not these copies.
- `Deep Learning Pipeline/DL_02_building_prediction.ipynb`
- `data/figures/dl_02_building_heldout_confusion_matrix.png`
- `data/figures/dl_02_building_training_curves.png`
- `data/tables/dl_02_building_heldout_per_class.csv`
- `data/tables/dl_02_building_metrics.csv`
- `docs/DL_PIPELINE.md`
- `requirements-dl.txt`
- `src/signal2space_dl/evaluate.py`
- `src/signal2space_dl/model.py`
