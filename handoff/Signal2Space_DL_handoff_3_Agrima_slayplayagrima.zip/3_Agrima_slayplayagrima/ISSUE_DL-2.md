# [DL-2] Building head: error review and missing-AP robustness (DL_02)

**ID:** DL-2 · **Step 2:** Parallel member work (start now on pre-created branches; PRs after DL-0 merges; DL-1 merges first)
**Owner:** Agrima (@slayplayagrima) · **Branch:** `dl/02-building-robustness-slayplayagrima` · **Effort (estimate):** about 4–6 hours
**Blocked by:** #8 (DL-0)
**When to start:** Start now on your pre-created branch, in parallel with DL-1, DL-3 and DL-4; open the PR after DL-0 merges; merge after DL-1
**Tracker:** #6

## Goal
Explain the building model's remaining errors and measure how accuracy degrades when detected access points go missing.

## Scope
- Run `DL_02_building_prediction.ipynb` with `RETRAIN = False`.
- Inspect the 2 held-out errors of `building_only` (both are true building 0 predicted as 1). Report `PHONEID`, `USERID`, the number of detected WAPs and the predicted probabilities, joining `dl_02_building_heldout_predictions.csv` to `data/raw/validationData.csv` on `ROW_ID`.
- Add `mask_detected_aps(X, fraction, rng)` to `src/signal2space_dl/evaluate.py`. It sets the given fraction of *detected* APs per row to the missing state: presence flag 0 and the preprocessor's fill value. Add a unit test for it.
- Robustness experiment on **internal validation only**: for fractions {0, 0.1, 0.2, 0.3, 0.5} and 5 seeds, measure building accuracy of the `building_only` and `multitask` checkpoints. Save `data/tables/dl_02_building_ap_masking_robustness.csv` and `data/figures/dl_02_building_ap_masking_robustness.png`, and add them to DL_02.

## Inputs
- `models/dl_02_building_model.pt`, `models/dl_05_multitask_model.pt`
- `src/signal2space_dl/evaluate.py`
- DL_02 notebook

## Outputs
- `mask_detected_aps` plus its test
- Robustness CSV and figure
- Error-review table and Findings in DL_02

## Acceptance criteria
- [ ] No retraining, and the committed checkpoints are unchanged.
- [ ] The robustness experiment uses internal validation only. The CSV has mean and standard deviation over the 5 seeds for each fraction and model.
- [ ] `pytest` passes and DL_02 runs top to bottom without errors.

## Workflow
Work on `dl/02-building-robustness-slayplayagrima` (pre-created from the integration branch). Commit with `DL-2: ... (refs #<this issue>)`, then push. Open a PR into `main` with `Closes #<this issue>` after DL-0 merges, and request review from @krishiv274.
Full step-by-step instructions: `Signal2Space_DL_handoff_3_Agrima_slayplayagrima.zip` (in `handoff/`) and `docs/TEAM_PLAN.md`.

Planner: https://app.notion.com/p/415e7fb36c6881d9b60effca159d11d5
