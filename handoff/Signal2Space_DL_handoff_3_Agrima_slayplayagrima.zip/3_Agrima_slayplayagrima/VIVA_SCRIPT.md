# Viva script

## Agrima (@slayplayagrima): Building classification head and robustness to missing access points
**Total planned length: 4:35** (limit 5:00). Square brackets mean: fill in from your own results before recording.

| Time | Section | What to say | What to show on screen |
|---|---|---|---|
| 0:00–0:35 (35 s) | My role | I own DL_02, the building head, and its robustness analysis. | DL-2 issue; `DL_02_building_prediction.ipynb` |
| 0:35–1:35 (60 s) | Model and training | It is the shared network with just the building head: three logits and cross-entropy. Early stopping on internal validation picked epoch 13 of 28. | `model.py`; `dl_02_building_training_curves.png`; `models/dl_02_building_model.json` |
| 1:35–2:35 (60 s) | Held-out result | 99.82% held-out accuracy against 99.73% for the Random Forest. That is one row, and the bootstrap interval includes zero, so building is essentially solved by both. | DL_02 metrics and AML comparison cells; `dl_02_building_heldout_confusion_matrix.png` |
| 2:35–3:15 (40 s) | Error review | Both errors are building 0 predicted as building 1. [Quote the phone and user IDs and WAP counts from your table.] | Your error-review table in DL_02 |
| 3:15–4:35 (80 s) | Robustness | I hid 10 to 50% of the detected access points on internal validation and measured accuracy. [Quote the curve.] This tells us how the model behaves when a phone hears fewer networks. | `dl_02_building_ap_masking_robustness.png`; `evaluate.py::mask_detected_aps`; your DL-2 PR |

**One-line summary of your contribution:** Explain the building model's remaining errors and measure how accuracy degrades when detected access points go missing. It connects to the full project as one stage of a single pipeline: DL_01 data, then DL_02–DL_04 heads, then DL_05 comparison with AML.

**Recording tips:** use 1080p screen capture and zoom the editor to about 125%. Open every file and tab before you start. Rehearse once with a timer and cut words rather than talking faster.

